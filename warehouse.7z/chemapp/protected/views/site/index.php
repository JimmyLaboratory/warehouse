<?php $this->pageTitle=Yii::app()->name; ?>

<h1>欢迎使用 <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>

<?php 
if(Yii::app()->user->isGuest):
        echo '<p>请使用你的帐户及密码登录系统</p>';
else:
        echo '<p>'.Yii::app()->user->getName().'，您好，请从导航栏选择您需要的操作。</p>';
		echo '<p>您当前的权限是：<i>普通用户</i></p>';
		echo '<p>如果您首次使用化学品，请先<b>申请采购</b>，</p>';
		echo '<p>如果您的化学品仍有库存，可<b>申请使用</b>。</p>';
endif;
?>
