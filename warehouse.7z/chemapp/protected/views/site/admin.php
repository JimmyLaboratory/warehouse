<?php $this->pageTitle=Yii::app()->name; ?>

<h1>欢迎使用 <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>

<p>管理项如下</p>

<p><a target="_blank" href="index.php?r=supplier">供应商管理</a></p>
<p><a target="_blank" href="index.php?r=chemcat">化学品分类管理</a></p>
<p><a target="_blank" href="index.php?r=quality">化学品规格管理</a></p>
<p><a target="_blank" href="index.php?r=unit">化学品国际单位管理</a></p>
<p><a target="_blank" href="index.php?r=department">学院部门管理</a></p>
<p><a target="_blank" href="index.php?r=storage">仓库管理</a></p>
