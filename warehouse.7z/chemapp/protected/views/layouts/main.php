<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="language" content="en" />

	<!-- blueprint CSS framework -->
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/screen.css" media="screen, projection" />
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/print.css" media="print" />
	<!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/ie.css" media="screen, projection" />
	<![endif]-->

	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/main.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/form.css" />

	<title><?php echo CHtml::encode($this->pageTitle); ?></title>
</head>

<body>

<div class="container" id="page">

	<div id="header">
		<div id="logo"><?php echo CHtml::encode(Yii::app()->name); ?></div>
	</div><!-- header -->

	<div id="mainmenu">
		<?php $this->widget('zii.widgets.CMenu',array(
			'items'=>array(
				array('label'=>'首页', 'url'=>array('/site/index')),
				array('label'=>'采购申请', 'url'=>array('/purchasing/apply'),'visible'=>Yii::app()->authManager->checkAccess('teacher',Yii::app()->user->getId())),
                                array('label'=>'采购申请审批', 'url'=>array('/purchasing/admin','status'=>'APPROVE'),'visible'=>
                                    Yii::app()->authManager->checkAccess('school',Yii::app()->user->getId()) ||
                                    Yii::app()->authManager->checkAccess('secure',Yii::app()->user->getId()) ||
                                    Yii::app()->authManager->checkAccess('college',Yii::app()->user->getId())
                                    ),
				array('label'=>'使用申请', 'url'=>array('/using/create'),'visible'=>Yii::app()->authManager->checkAccess('teacher',Yii::app()->user->getId())),
                                array('label'=>'使用申请审批', 'url'=>array('/using/admin','status'=>'APPROVE'),'visible'=>
                                    Yii::app()->authManager->checkAccess('school',Yii::app()->user->getId()) ||
                                    Yii::app()->authManager->checkAccess('college',Yii::app()->user->getId())
                                    ),
                                array('label'=>'采购单', 'url'=>array('/purchasing/no'),'visible'=>Yii::app()->authManager->checkAccess('school',Yii::app()->user->getId())),
                                array('label'=>'采购入库', 'url'=>array('/purchasing/admin','Purchasing[status]'=>  Purchasing::STATUS_PURCHASING),'visible'=>Yii::app()->authManager->checkAccess('school',Yii::app()->user->getId())),
                                array('label'=>'备案单', 'url'=>array('/achieve/admin'),'visible'=>Yii::app()->authManager->checkAccess('school',Yii::app()->user->getId())),
                                array('label'=>'使用出库', 'url'=>array('/outstorage/create'),'visible'=>Yii::app()->authManager->checkAccess('school',Yii::app()->user->getId())),
                                array('label'=>'查看化学品', 'url'=>array('/chemlist/admin'), 'visible'=>!Yii::app()->user->isGuest),
                                array('label'=>'系统管理', 'url'=>array('/site/admin'),'visible'=>Yii::app()->authManager->checkAccess('school',Yii::app()->user->getId())),
                                array('label'=>'用户管理', 'url'=>array('/user'),'visible'=>
                                    Yii::app()->authManager->checkAccess('school',Yii::app()->user->getId()) ||
                                    Yii::app()->authManager->checkAccess('college',Yii::app()->user->getId())||
                                    Yii::app()->authManager->checkAccess('secure',Yii::app()->user->getId())
                                    ),
                                array('label'=>'修改信息', 'url'=>array('/user/update','id'=>User::getInfo() ? User::getInfo()->user_id : ''),'visible'=>!Yii::app()->user->isGuest),
				array('label'=>'登录', 'url'=>array('/site/login'), 'visible'=>Yii::app()->user->isGuest),
				array('label'=>'退出 ('.Yii::app()->user->name.')', 'url'=>array('/site/logout'), 'visible'=>!Yii::app()->user->isGuest)
			),
		)); ?>
	</div><!-- mainmenu -->
	

	<?php echo $content; ?>

	<div class="clear"></div>

	<div id="footer">
		Copyright &copy; <?php echo date('Y'); ?> by School.<br/>
		All Rights Reserved.
	</div><!-- footer -->

</div><!-- page -->

</body>
</html>
