<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>危险品备案单</title>
<style type="text/css">
body{
	font-size: 16px;
}
</style>
</head>

<body>
<div >
  <table width="100%" border="0">
    <tr>
      <td colspan="3" align="center"><h1>危险品备案单</h1></td>
    </tr>
    <tr>
      <td width="33%">备案单编号：<?php echo $model->achieve_id ?></td>
      <td width="33%">&nbsp;</td>
      <td width="33%">打印日期：<?php echo date('Y-m-d') ?></td>
    </tr>
    <tr>
      <td width="33%">备案人姓名：<?php echo $model->achiever ?></td>
      <td width="33%">联系电话：</td>
      <td width="33%">备案人签字：</td>
    </tr>
  </table>
  <table width="100%" border="1" align="center" cellpadding="1" cellspacing="1" >
    <tr >
      <td width="211" valign="center" ><p >化学品名称 </p></td>
      <td width="178" valign="center" ><p >规格 </p></td>
      <td width="178" valign="center" ><p >包装 </p></td>
      <td width="215" valign="center" ><p >申购数量 </p></td>
    </tr>
<?php
$achieve_info = json_decode($model->achieve_info,true);
foreach($achieve_info as $info):
?>
    <tr >
      <td width="211" valign="center" ><p ><?php echo $info['chem_name'] ?></p></td>
      <td width="178" valign="center" ><p ><?php echo $info['quality'] ?></p></td>
      <td width="178" valign="center" ><p ><?php echo $info['unit'] ?></p></td>
      <td width="215" valign="center" ><p ><?php echo $info['nums'] ?></p></td>
    </tr>
<?php
endforeach;
?>
    
  </table>
  <p ></p>
</div>
</body>
</html>
