<h1>更改化学品归属</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>