<h1>修改用户密码</h1>

<?php echo $this->renderPartial('_passwd', array('model'=>$model)); ?>